<?php

include 'book-utilities.inc.php';




?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Chapter 12</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.1.3/material.blue_grey-orange.min.css">

    <link rel="stylesheet" href="styles.css">
    
    
    <script   src="https://code.jquery.com/jquery-1.7.2.min.js" ></script>
       
    <script src="https://code.getmdl.io/1.1.3/material.min.js"></script>
    <script src="jquery.sparkline.2.1.2.js"></script>
    
  
</head>

<body>
    
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer
            mdl-layout--fixed-header">
            
    <?php include 'header.inc.php'; ?>
    <?php include 'left-nav.inc.php'; ?>
    
    <main class="mdl-layout__content mdl-color--grey-50">
        <section class="page-content">

            <div class="mdl-grid">

              <!-- mdl-cell + mdl-card -->
              <div class="mdl-cell mdl-cell--7-col card-lesson mdl-card  mdl-shadow--2dp">
                <div class="mdl-card__title mdl-color--orange">
                  <h2 class="mdl-card__title-text">Customers</h2>
                </div>
                <div class="mdl-card__supporting-text">
                    <table class="mdl-data-table  mdl-shadow--2dp">
                      <thead>
                        <tr>
                          <th class="mdl-data-table__cell--non-numeric">Name</th>
                          <th class="mdl-data-table__cell--non-numeric">University</th>
                          <th class="mdl-data-table__cell--non-numeric">City</th>
                          <th>Sales</th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php
                          $customers = array();
                          $content = file('customers.txt') or die('ERROR: Cannot find file');
                          foreach ($content as $field) {
                              $fields = explode(';', $field);
                              $customer = array(
                                  'id' => $fields[0],
                                  'firstname' => $fields[1],
                                  'lastname' => $fields[2],
                                  'email' => $fields[3],
                                  'university' => $fields[4],
                                  'address' => $fields[5],
                                  'city' => $fields[6],
                                  'state' => $fields[8],
                                  'zip' => $fields[9],
                                  'phone' => $fields[10]
                              );
                              $customers[] = $customer; 
                          }
                          foreach ($customers as $customer) {
                              $name = $customer['firstname'] . ' ' . $customer['lastname'];
                              echo '<tr><td><a href="chapter12-project3.php?id=' . $customer['id']. '">' . $name . '</a></td>';
                              echo '<td>' . $customer['university'] . '</td>';
                              echo '<td>' . $customer['city'] . '</td></tr>';
                          }
                      ?>
                      </tbody>
                    </table>
                </div>
              </div>  <!-- / mdl-cell + mdl-card -->
              
              
            <div class="mdl-grid mdl-cell--5-col">
    

       
                  <!-- mdl-cell + mdl-card -->
                  <div class="mdl-cell mdl-cell--12-col card-lesson mdl-card  mdl-shadow--2dp">
                    <div class="mdl-card__title mdl-color--deep-purple mdl-color-text--white">
                      <h2 class="mdl-card__title-text">Customer Details</h2>
                    </div>
                    <div class="mdl-card__supporting-text">
                        <h4><?php 
                            foreach ($customers as $customer) {
                                $customer_id = $_GET['id'];
                                if ($customer['id'] == $customer_id) {
                                    $customername = $customer['firstname'] . ' ' . $customer['lastname'];
                                    echo $customername;
                                }
                            }
                                ?>
                                </h4>
                            <?php
                            foreach ($customers as $customer) {
                                $customer_id = $_GET['id'];
                                if ($customer['id'] == $customer_id) {
                                    echo "<br>";
                                    echo $customer['address'];
                                    echo "<br>";
                                    echo $customer['city'];
                                    echo ", ";
                                    echo $customer['state'];
                                    echo " ";
                                    echo $customer['zip'];
                                    echo "<br>";
                                    echo $customer['phone'];
                                }
                            }
                            ?>
                    </div>    
                  </div>  <!-- / mdl-cell + mdl-card -->   

                  <!-- mdl-cell + mdl-card -->
                  <div class="mdl-cell mdl-cell--12-col card-lesson mdl-card  mdl-shadow--2dp">
                    <div class="mdl-card__title mdl-color--deep-purple mdl-color-text--white">
                      <h2 class="mdl-card__title-text">Order Details</h2>
                    </div>
                    <div class="mdl-card__supporting-text">       
                               
                                                                      

                               <table class="mdl-data-table  mdl-shadow--2dp">
                              <thead>
                                <tr>
                                  <th class="mdl-data-table__cell--non-numeric">Cover</th>
                                  <th class="mdl-data-table__cell--non-numeric">ISBN</th>
                                  <th class="mdl-data-table__cell--non-numeric">Title</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php
                            if (isset($_GET['id'])) {
                                $orders = array();
                                $content = file('orders.txt') or die('ERROR: Cannot find file');
                                $customer_id = $_GET['id'];
                                foreach ($content as $ord) {
                                    $fields = explode(',', $ord);
                                    $orderid = $fields[1];
                                    if ($orderid == $customer_id) {
                                        $order = array(
                                            'isbn' => $fields[2],
                                            'title' => $fields[3],
                                        );
                                        $orders[] = $order;
                                    }
                                }
}
                                if (count($orders) > 0) {
                                    foreach ($orders as $order) {
                                        echo '<tr>';
                                        echo '<td></td>';
                                        echo '<td>' . $order['isbn'] . '</td>';
                                        echo '<td>' . $order['title'] . '</td>';
                                        echo '</tr>';
                                    }
                                } 
                                else {
                                    foreach ($customers as $customer) {
                                      $customer_id = $_GET['id'];
                                      if ($customer['id'] == $customer_id) {
                                      $customername = $customer['firstname'] . ' ' . $customer['lastname'];
                                      echo "No orders for ". $customername;
                                }
                                }
                            }
?>
                    
                              </tbody>
                            </table>
       

                        </div>    
                   </div>  <!-- / mdl-cell + mdl-card -->             


               </div>   
           
           
            </div>  <!-- / mdl-grid -->    

        </section>
    </main>    
</div>    <!-- / mdl-layout --> 
          
</body>
</html>