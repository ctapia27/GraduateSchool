<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title> Course Management Systems - New Course </title>
</head>
<body>

<?php
/*
Filename: add_yourname.php
Description: This file takes the data provided by a form and adds it to a table within a MySQL database
Author: Carla Tapia
Date: November 7, 2023
*/

//MySQL connection parameters. Remains the same for all connections to the database
$servername = "carlaistm.shop";
$username = "CarlaT";
$password = "QZ6v0tn@VNFW";
$dbname = "faculty";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//Select database
mysqli_select_db ($conn , $dbname);

// SQL statement to insert form posted data into table:course and store statement in a variable $sql
// the variable parameters on the right are inside the $_POST are received from the form.
// Code below is an example.

$sql = "INSERT INTO faculty_info set RECORD_NO = '$_POST[record_no]',
FACULTY_ID = '$_POST[faculty_id]',
FACULTY_LASTNAME = '$_POST[faculty_lastname]',
FACULTY_FIRSTNAME = '$_POST[faculty_firstname]',
FACULTY_OFFICE = '$_POST[faculty_office]'";

// Insert SQL data in MySQL database table
mysqli_query($conn, $sql);

// Display confirmation
echo "Your new course has been created. <br>";

// Close connection
mysqli_close($conn);
?>
</span>

</body>
</html>
