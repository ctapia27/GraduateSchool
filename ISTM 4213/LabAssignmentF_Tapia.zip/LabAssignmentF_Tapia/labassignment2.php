<?php
//Created by Carla Tapia
//Date: 12/05/2023
 ?>

<!DOCTYPE html>
<html lang=en>
<head>
    <title>Crypto data</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.blue_grey-orange.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
      <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Web Service Processing (JSON Server-Side)</span>
        </div>
      </header>

      <main class="mdl-layout__content">
        <div class="page-content">
            <div class="mdl-grid">

              <table class="mdl-data-table mdl-js-data-table  mdl-shadow--2dp">
                <thead>
                  <tr>
                    <td colspan="3" style="text-align:center">Products</td>
                  </tr>
                  <tr>
                    <th style="text-align:center">Title </th>
                    <th style="text-align:center">Description </th>
                    <th style="text-align:center">Price </th>
                  </tr>
                </thead>
              <tbody>


              <?php

              $hostname="carlaistm.shop";
              $username="carlatap";
              $password="Onk3e~D5hNm0";
              $dbname = "products";
              
              $con = mysqli_connect($hostname, $username, $password, $dbname);
              
              if(mysqli_connect_error()) {
                  echo "Failed to connect" . mysqli_connect_error();
                }
            
              // Initializing curl
              $curl = curl_init();

              // Sending GET request to reqres.in
              // server to get JSON data
              curl_setopt($curl, CURLOPT_URL,
              	"https://dummyjson.com/products");

              // Telling curl to store JSON
              // data in a variable instead
              // of dumping on screen
              curl_setopt($curl,CURLOPT_RETURNTRANSFER, true);

              // Executing curl
              $data = curl_exec($curl);
              //to get output for question #6 I comment out line 51
              //echo $data;

              // Checking if any error occurs
              // during request or not
              if($e = curl_error($curl)) {
              	echo $e;
              } else {
                $myArray = json_decode($data, true);
                if(isset($myArray['products'])){
                    $array = $myArray['products'];
                    foreach($array as $array){
                        $id = $array['id'];
                        $title = htmlspecialchars($array['title']);
                        $description = htmlspecialchars($array['description']);
                        $price = $array['price'];
                        $discountpercent = $array['discountPercentage'];
                        $rating = $array['rating'];
                        $stock = $array['stock'];
                        $brand = htmlspecialchars($array['brand']);
                        $categorgy = htmlspecialchars($array['category']);

                        $sql = "INSERT INTO products (product_id, title, description_, price, discountpercent, rating, stock, brand, category) VALUES 
                        ('$id', '$title', '$description', '$price', '$discountpercent', '$rating', '$stock', '$brand', '$categorgy')";

                            if ($con->query($sql) === TRUE) {
                                echo "Product '$title' inserted successfully.<br>";
                                header("Location: tabledisplay.php");
                            } else {
                                echo "Error inserting product <br>";
                            }
                            }
                    }
                }

              // Closing curl
              curl_close($curl);
             ?>

           </tbody>


         </table>
            </div>
        </div>
      </main>
    </div>
</body>
</html>