<!DOCTYPE html>
<html lang=en>
<head>
    <title>Product Data</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.blue_grey-orange.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
      <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
          <span class="mdl-layout-title">Web Service Processing (JSON Server-Side)</span>
        </div>
      </header>

      <main class="mdl-layout__content">
        <div class="page-content">
            <div class="mdl-grid">

              <table class="mdl-data-table mdl-js-data-table  mdl-shadow--2dp">
                <thead>
                  <tr>
                    <td colspan="3" style="text-align:center">Products</td>
                  </tr>
                  <tr>
                    <th style="text-align:center">Title </th>
                    <th style="text-align:center">Description </th>
                    <th style="text-align:center">Price </th>
                    <th style="text-align:center">Discount Percentage </th>
                    <th style="text-align:center">Rating </th>
                    <th style="text-align:center">Stock </th>
                    <th style="text-align:center">Brand </th>
                    <th style="text-align:center">Category </th>
                  </tr>
                </thead>
              <tbody>

<?php
// Connect to MySQL (modify these parameters)
$servername = "carlaistm.shop";
$username = "carlatap";
$password = "Onk3e~D5hNm0";
$dbname = "products";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch records from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

// Check if records are found
if ($result->num_rows > 0) {
    // Loop through each record and display information
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td style="text-align:center">'.$row['title'].'</br>'.'</td>';
        echo	'<td style="text-align:center">'.$row['price'].'</br>'.'</td>';
        echo	'<td style="text-align:center">'.$row['description_'].'</br>'.'</td>';
        echo	'<td style="text-align:center">'.$row['discountpercent'].'</br>'.'</td>';
        echo	'<td style="text-align:center">'.$row['rating'].'</br>'.'</td>';
        echo	'<td style="text-align:center">'.$row['stock'].'</br>'.'</td>';
        echo	'<td style="text-align:center">'.$row['brand'].'</br>'.'</td>';
        echo	'<td style="text-align:center">'.$row['category'].'</br>'.'</td>';
        echo '</tr>';

    }
} else {
    echo "<p>No records found in the database.</p>";
}

// Close the database connection
$conn->close();
?>

</body>
</html>
